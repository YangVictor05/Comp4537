const MESSAGES = {
    prompt: "How many buttons to create?",
    errorInvalidInput: "Please enter a valid number between 3 and 7.",
    errorWrongOrder: "Wrong order!",
    successExcellentMemory: "Excellent memory!",
    start: 'Go!',
    buttonClick: 'Button clicked!',
}
