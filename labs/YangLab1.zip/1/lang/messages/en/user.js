const messages = {
    wPage: "Writer Page",
    rPage: "Reader Page",
    labTitle: "Lab 1: JSON, Object Constructor, localStorage",
    writerLink: "Go to Writer",
    readerLink: "Go to Reader",
    name: "Victor Yang",
    add: "Add",
    remove: "Remove",
    back: "Back",
    lastSavedTime: "Last saved:",
    lastRetrievedTime: "Last retrieved:",
  };
  